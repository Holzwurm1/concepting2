import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { PluginData } from "@/types/plugin";

function generateId(): string {
  return crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

function toDb(plugin: Partial<PluginData>): Record<string, unknown> {
  return {
    name: plugin.name ?? "",
    version: plugin.version ?? "1.0.0",
    description: plugin.description ?? "",
    author: plugin.author ?? "",
    authors: plugin.authors ?? [],
    main: plugin.main ?? "",
    api_version: plugin.apiVersion ?? "1.20",
    soft_depend: plugin.softDepend ?? [],
    depend: plugin.depend ?? [],
    load_before: plugin.loadBefore ?? [],
    prefix: plugin.prefix ?? null,
    website: plugin.website ?? null,
    tagline: plugin.tagline ?? "",
    tags: plugin.tags ?? [],
    commands: plugin.commands ?? [],
    permissions: plugin.permissions ?? [],
    items: plugin.items ?? [],
    recipes: plugin.recipes ?? [],
    notes: plugin.notes ?? "",
    updated_at: new Date().toISOString(),
  };
}

function fromDb(row: Record<string, unknown>): PluginData {
  return {
    id: String(row.id),
    name: String(row.name ?? ""),
    version: String(row.version ?? "1.0.0"),
    description: String(row.description ?? ""),
    author: String(row.author ?? ""),
    authors: Array.isArray(row.authors) ? row.authors.map(String) : [],
    main: String(row.main ?? ""),
    apiVersion: String(row.api_version ?? "1.20"),
    softDepend: Array.isArray(row.soft_depend) ? row.soft_depend.map(String) : [],
    depend: Array.isArray(row.depend) ? row.depend.map(String) : [],
    loadBefore: Array.isArray(row.load_before) ? row.load_before.map(String) : [],
    prefix: row.prefix ? String(row.prefix) : undefined,
    website: row.website ? String(row.website) : undefined,
    tagline: String(row.tagline ?? ""),
    tags: Array.isArray(row.tags) ? row.tags.map(String) : [],
    commands: Array.isArray(row.commands) ? row.commands : [],
    permissions: Array.isArray(row.permissions) ? row.permissions : [],
    items: Array.isArray(row.items) ? row.items : [],
    recipes: Array.isArray(row.recipes) ? row.recipes : [],
    notes: String(row.notes ?? ""),
    createdAt: String(row.created_at ?? new Date().toISOString()),
    updatedAt: String(row.updated_at ?? new Date().toISOString()),
  };
}

export function usePlugins() {
  const [plugins, setPlugins] = useState<PluginData[]>([]);
  const [loaded, setLoaded] = useState(false);

  const fetchPlugins = useCallback(async () => {
    const { data, error } = await supabase
      .from("plugins")
      .select("*")
      .order("updated_at", { ascending: false });
    if (error) {
      console.error("Supabase error:", error);
      return;
    }
    setPlugins((data ?? []).map(fromDb));
    setLoaded(true);
  }, []);

  useEffect(() => {
    fetchPlugins();
  }, [fetchPlugins]);

  const addPlugin = useCallback(async (partial?: Partial<PluginData>) => {
    const id = generateId();
    const now = new Date().toISOString();
    const insert = {
      id,
      ...toDb(partial ?? {}),
      created_at: now,
      updated_at: now,
    };
    const { data, error } = await (supabase as any).from("plugins").insert(insert).select().single();
    if (error) {
      console.error("addPlugin error:", error);
      return undefined;
    }
    const plugin = fromDb(data as Record<string, unknown>);
    setPlugins((prev) => [plugin, ...prev]);
    return plugin;
  }, []);

  const updatePlugin = useCallback(async (id: string, updater: Partial<PluginData> | ((prev: PluginData) => PluginData)) => {
    const current = plugins.find((p) => p.id === id);
    if (!current) return;
    const updated = typeof updater === "function" ? updater(current) : { ...current, ...updater, updatedAt: new Date().toISOString() };
    const { error } = await (supabase as any).from("plugins").update(toDb(updated)).eq("id", id);
    if (error) {
      console.error("updatePlugin error:", error);
      return;
    }
    setPlugins((prev) => prev.map((p) => (p.id === id ? { ...updated, id } : p)));
  }, [plugins]);

  const deletePlugin = useCallback(async (id: string) => {
    const { error } = await supabase.from("plugins").delete().eq("id", id);
    if (error) {
      console.error("deletePlugin error:", error);
      return;
    }
    setPlugins((prev) => prev.filter((p) => p.id !== id));
  }, []);

  const getPlugin = useCallback((id: string): PluginData | undefined => {
    return plugins.find((p) => p.id === id);
  }, [plugins]);

  return { plugins, loaded, addPlugin, updatePlugin, deletePlugin, getPlugin, refresh: fetchPlugins };
}