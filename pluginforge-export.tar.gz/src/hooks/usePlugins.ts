import { useState, useEffect, useCallback } from "react";
import type { PluginData } from "@/types/plugin";

const STORAGE_KEY = "pluginforge_plugins";

function generateId(): string {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

function createEmptyPlugin(): PluginData {
  const now = new Date().toISOString();
  return {
    id: generateId(),
    name: "",
    version: "1.0.0",
    description: "",
    author: "",
    authors: [],
    main: "",
    apiVersion: "1.20",
    softDepend: [],
    depend: [],
    loadBefore: [],
    tagline: "",
    tags: [],
    commands: [],
    permissions: [],
    items: [],
    recipes: [],
    notes: "",
    createdAt: now,
    updatedAt: now,
  };
}

function loadPlugins(): PluginData[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as PluginData[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function savePlugins(plugins: PluginData[]): void {
  if (typeof window === "undefined") return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(plugins));
}

export function usePlugins() {
  const [plugins, setPlugins] = useState<PluginData[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    setPlugins(loadPlugins());
    setLoaded(true);
  }, []);

  const addPlugin = useCallback((partial?: Partial<PluginData>) => {
    const plugin = { ...createEmptyPlugin(), ...partial, id: generateId(), createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
    setPlugins((prev) => {
      const next = [plugin, ...prev];
      savePlugins(next);
      return next;
    });
    return plugin;
  }, []);

  const updatePlugin = useCallback((id: string, updater: Partial<PluginData> | ((prev: PluginData) => PluginData)) => {
    setPlugins((prev) => {
      const next = prev.map((p) => {
        if (p.id !== id) return p;
        const updated = typeof updater === "function" ? updater(p) : { ...p, ...updater, updatedAt: new Date().toISOString() };
        return { ...updated, updatedAt: new Date().toISOString() };
      });
      savePlugins(next);
      return next;
    });
  }, []);

  const deletePlugin = useCallback((id: string) => {
    setPlugins((prev) => {
      const next = prev.filter((p) => p.id !== id);
      savePlugins(next);
      return next;
    });
  }, []);

  const getPlugin = useCallback((id: string): PluginData | undefined => {
    return plugins.find((p) => p.id === id);
  }, [plugins]);

  return { plugins, loaded, addPlugin, updatePlugin, deletePlugin, getPlugin };
}